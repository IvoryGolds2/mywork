<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta property="og:image" content="">
<meta property="og:title" content="알뜰교통카드 활용 알리미">
<meta property="og:description" content="알뜰교통카드 활용 알리미">
<meta name="google-site-verification" content="l-4dhiJdxGRyKMUr3l4d334vllaOIBhb3hT8aQw-VTw" />
<link rel="stylesheet" href="./css/reset.css">
<link rel="stylesheet" href="./css/common.css">
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"
/>
<script type="module">
  import Swiper from 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.mjs'
</script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="./js/postData.js"></script>
<script src="./js/main.js"></script>
<title>알뜰교통카드 활용 알리미</title>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2858778486116301" crossorigin="anonymous"></script>
<script>
    if ( window.location.href == "http://system.dab969879.co.kr/"
        || window.location.href == "https://system.dab969879.co.kr/") {
        window.location.href = "https://system.cacaochocolat.co.kr/";
    }
    if ( window.location.href == "http://system.dab969879.co.kr/home.php"
        || window.location.href == "https://system.dab969879.co.kr/home.php") {
        window.location.href = "https://system.cacaochocolat.co.kr/home.php";
    }
</script>