<!DOCTYPE html>
<html lang="en">
<head>
  <?php 
  include './db.php';
  include './front_header.php';
  $category = $_POST['category'];
  ?>
	<link rel="stylesheet" href="./css/commmon.css">
</head>
<body>
  <header class="contentHeader">
    <a href="./home.php"><button>
      <img src="./img/sub-arrow.png" alt="">
    </button></a>
    <h1>알뜰교통카드 체크카드 종류</h1>
  </header>
  <section class="innerWrapper">
    <?php
      $sql = query("SELECT * from checkcard");
      foreach($sql as $key => $val) { ?>
      <div class="contentBoxThin">
        <button class="toggleButton" id="toggleButton<?=$key?>">
          <h1 class="orangeColor" id="orangeColor<?=$key?>"><?=$val['title']?></h1> 
          <img id="toggleIcon<?=$key?>" class="toggleIcon" src="./img/qna-down.png" alt="Show">
        </button>
        <div>
          <pre id="content<?=$key?>" class="content" style="display: none;"><?=$val['content']?></pre>
          <?php if($val['chart']) { ?><img id="contentImg<?=$key?>" class="contentImg" src="./img/<?=$val['chart']?>.png" style="display: none;"><?php } ?>
        </div>
      </div>
      <script>
        document.getElementById("toggleButton<?=$key?>").addEventListener("click", function() {
          var content = document.getElementById("content<?=$key?>");
          var toggleIcon = document.getElementById("toggleIcon<?=$key?>");
          var title = document.getElementById("orangeColor<?=$key?>");
          var contentImg = document.getElementById("contentImg<?=$key?>");
          
          if (content.style.display === "none") {
            content.style.display = "block";
            toggleIcon.src = "./img/qna-up.png"; 
            toggleIcon.alt = "Hide"; 
            title.style.color = "#ec6c10"; 
            contentImg.style.display = "inline"; 
          } else {
            content.style.display = "none";
            toggleIcon.src = "./img/qna-down.png";
            toggleIcon.alt = "Show";
            title.style.color = "black";
            contentImg.style.display = "none";
          }
        });
      </script>
    <?php  } ?>  
  </section>
</body>
</html>