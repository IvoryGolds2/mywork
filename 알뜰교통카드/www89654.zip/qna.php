<!DOCTYPE html>
<html lang="en">
<head>
  <?php 
  include './db.php';
  include './front_header.php';
  $category = $_POST['category'];
  ?>
	<link rel="stylesheet" href="./css/commmon.css">
</head>
<body>
  <header class="contentHeader">
    <a href="./home.php"><button>
      <img src="./img/sub-arrow.png" alt="">
    </button></a>
    <h1>알뜰교통카드 자주 묻는 질문</h1>
  </header>
  <section class="innerWrapper">
    <?php
      $sql = query("SELECT * from traffic_qna");
      foreach($sql as $key => $val) { ?>
      <div class="contentBoxThin2">
        <button class="toggleButton2" id="toggleButton<?=$key?>">
          <h1 class="orangeColor" id="orangeColor<?=$key?>"><?=$val['title']?></h1> 
          <img id="toggleIcon<?=$key?>" class="toggleIcon" src="./img/qna-down.png" alt="Show">
        </button>
        <div>
          <pre id="content<?=$key?>" class="content" style="display: none;"><?=$val['content']?></pre>
        </div>
      </div>
      <script>
        document.getElementById("toggleButton<?=$key?>").addEventListener("click", function() {
          var content = document.getElementById("content<?=$key?>");
          var toggleIcon = document.getElementById("toggleIcon<?=$key?>");
          var title = document.getElementById("orangeColor<?=$key?>");
          
          if (content.style.display === "none") {
            content.style.display = "block";
            toggleIcon.src = "./img/qna-up.png";
            toggleIcon.alt = "Hide";
            title.style.color = "#ec6c10";
          } else {
            content.style.display = "none";
            toggleIcon.src = "./img/qna-down.png";
            toggleIcon.alt = "Show";
            title.style.color = "black";
          }
        });
      </script>
    <?php  } ?>  
  </section>
</body>
</html>